function dataRead(adc_file_name, configurationFileName, pathname, filename)

% clc
% clear all
% close all

% dataName = 'ges9';
% adc_file_name = ['E:\design\code\originData\20220308-2\', dataName, '.bin'];
% configurationFileName = '20220308-2.cfg';
% %存储路径
% pathname = 'E:\design\code\雷达实验-手势识别\rawData\20220308-2\';
% filename = [dataName, '.mat'];

cliCfg = readCfg(configurationFileName);
Params = parseCfg(cliCfg);

num_of_frames = Params.frameCfg(4);  %帧数
device_sel = Params.device_sel;

%signal process parameter,信号处理参数
channelCfg = Params.channelCfg;
adcCfg     = Params.adcCfg;
adcbufCfg  = Params.adcbufCfg;
profileCfg = Params.profileCfg;
frameCfg   = Params.frameCfg;
lowPower   = Params.lowPower;
guiMonitor = Params.guiMonitor;
cfarCfg    = Params.cfarCfg;
doaCfg     = Params.doaCfg;

%ad_data_out为采集数据，格式为：接收通道数4 * 每个chirp内采样数256 * 每帧chirp数384 * 帧数1000
[ad_data_out,nchirp,nframe,samplesInChirp] = MmwDemo_ADC_data_process(adc_file_name,profileCfg,frameCfg,num_of_frames,device_sel,adcbufCfg(1));
%存储.mat文件
if exist(pathname) == 0
    mkdir(pathname);
end
save ([pathname, filename],'ad_data_out');
end

% MainProcess1T(Params); %一发
% MainProcess2T(Params); %两发
% MainProcess1T_dynamic(Params);  %动图

