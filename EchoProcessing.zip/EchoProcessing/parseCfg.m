function [P, cliCfg] = parseCfg(cliCfg)
    P=[];
    for k=1:length(cliCfg)
        C = strsplit(cliCfg{k});
        if strcmp(C{1},'channelCfg')
            P.channelCfg(1) = str2double(C{2});
            P.channelCfg(2) = str2double(C{3});
            P.channelCfg(3) = str2double(C{4});
        elseif strcmp(C{1},'adcCfg')
            P.adcCfg(1) = str2double(C{2});
            P.adcCfg(2) = str2double(C{3}); 
        elseif strcmp(C{1},'adcbufCfg')
            P.adcbufCfg(1) = str2double(C{2});
            P.adcbufCfg(2) = str2double(C{3}); 
            P.adcbufCfg(3) = str2double(C{4}); 
            P.adcbufCfg(4) = str2double(C{5}); 
        elseif strcmp(C{1},'profileCfg')
            P.profileCfg(1)  = str2double(C{2});
            P.profileCfg(2)  = str2double(C{3}); 
            P.profileCfg(3)  = str2double(C{4}); 
            P.profileCfg(4)  = str2double(C{5}); 
            P.profileCfg(5)  = str2double(C{6});
            P.profileCfg(6)  = str2double(C{7});
            P.profileCfg(7)  = str2double(C{8}); 
            P.profileCfg(8)  = str2double(C{9}); 
            P.profileCfg(9)  = str2double(C{10}); 
            P.profileCfg(10) = str2double(C{11}); 
            P.profileCfg(11) = str2double(C{12}); 
            P.profileCfg(12) = str2double(C{13}); 
            P.profileCfg(13) = str2double(C{14}); 
            P.profileCfg(14) = str2double(C{15}); 
        elseif strcmp(C{1},'frameCfg')
            P.frameCfg(1)  = str2double(C{2});
            P.frameCfg(2)  = str2double(C{3}); 
            P.frameCfg(3)  = str2double(C{4}); 
            P.frameCfg(4)  = str2double(C{5}); 
            P.frameCfg(5)  = str2double(C{6});
            P.frameCfg(6)  = str2double(C{7});
            P.frameCfg(7)  = str2double(C{8}); 
        elseif strcmp(C{1},'lowPower')
            P.lowPower(1)  = str2double(C{2});
            P.lowPower(2)  = str2double(C{3}); 
        elseif strcmp(C{1},'guiMonitor')
            P.guiMonitor(1)  = str2double(C{2});
            P.guiMonitor(2)  = str2double(C{3}); 
            P.guiMonitor(3)  = str2double(C{4}); 
            P.guiMonitor(4)  = str2double(C{5}); 
        elseif strcmp(C{1},'cfarCfg')
            P.cfarCfg(1)  = str2double(C{2});
            P.cfarCfg(2)  = str2double(C{3}); 
            P.cfarCfg(3)  = str2double(C{4}); 
            P.cfarCfg(4)  = str2double(C{5}); 
            P.cfarCfg(5)  = str2double(C{6});
            P.cfarCfg(6)  = str2double(C{7});
            P.cfarCfg(7)  = str2double(C{8}); 
            P.cfarCfg(8)  = str2double(C{9}); 
            P.cfarCfg(9)  = str2double(C{10}); 
            P.cfarCfg(10) = str2double(C{11}); 
            P.cfarCfg(11) = str2double(C{12}); 
        elseif strcmp(C{1},'doaCfg')
            P.doaCfg(1)  = str2double(C{2});
            P.doaCfg(2)  = str2double(C{3}); 
            P.doaCfg(3)  = str2double(C{4}); 
            P.doaCfg(4)  = str2double(C{5}); 
        elseif strcmp(C{1},'gateLimit')
            P.gateLimit(1) = str2double(C{2});
            P.gateLimit(2) = str2double(C{3}); 
            P.gateLimit(3) = str2double(C{4}); 
            P.gateLimit(4) = str2double(C{5}); 
        elseif strcmp(C{1},'stateParam')
            P.stateParam(1) = str2double(C{2});
            P.stateParam(2) = str2double(C{3});
            P.stateParam(3) = str2double(C{4});
            P.stateParam(4) = str2double(C{5});
            P.stateParam(5) = str2double(C{6});
        elseif strcmp(C{1},'allocationParam')
            P.allocationParam(1) = str2double(C{2});
            P.allocationParam(2) = str2double(C{3}); 
            P.allocationParam(3) = str2double(C{4}); 
            P.allocationParam(4) = str2double(C{5}); 
            P.allocationParam(5) = str2double(C{6}); 
        elseif strcmp(C{1},'variationParam')
            P.variationParam(1) = str2double(C{2});
            P.variationParam(2) = str2double(C{3});
            P.variationParam(3) = str2double(C{4});
        elseif strcmp(C{1},'trackingcfg')
            P.trackingcfg(1) = str2double(C{2});
            P.trackingcfg(2) = str2double(C{3});
            P.trackingcfg(3) = str2double(C{4});
            P.trackingcfg(4) = str2double(C{5});
            P.trackingcfg(5) = str2double(C{6});
            P.trackingcfg(6) = str2double(C{7});
            P.trackingcfg(7) = str2double(C{8});
            P.trackingcfg(8) = str2double(C{9});
        elseif strcmp(C{1},'num_of_frame')
            P.num_of_frame(1) = str2double(C{2});
        elseif strcmp(C{1},'device_sel')
            P.device_sel(1) = str2double(C{2});
        elseif strcmp(C{1},'unrollingParam')
            P.unrollingParam(1) = str2double(C{2});
            P.unrollingParam(2) = str2double(C{3}); 
        elseif strcmp(C{1},'pausetime')
            P.pausetime(1) = str2double(C{2});
        end
    end
end

